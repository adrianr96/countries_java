package com.example.countries;

import android.widget.ArrayAdapter;

import androidx.recyclerview.widget.RecyclerView;

public class CountryAdapter extends RecyclerView.Adapter<Country> {


}
